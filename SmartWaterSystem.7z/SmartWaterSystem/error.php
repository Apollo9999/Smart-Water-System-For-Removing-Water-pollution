<?php

echo '<html>
<head>
<title>Error</title>
<body>
<p id="error">An Error occured while Login-Kindly try Again in a while with the correct Credentials</p>
<button id="button"><a href ="index.html">RETRY</a></button>
<style>

#error {
text-align: center;
font-size: medium;
}
#button {
  background-color: lightgrey; /* Green */
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
   margin-left:600px;
}
</style>
</body>
</html>';



